enum NetworkType {
  wifi,
  cellular,
}
