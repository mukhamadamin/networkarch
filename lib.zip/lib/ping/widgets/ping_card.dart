// Flutter imports:
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// Package imports:
import 'package:dart_ping/dart_ping.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// Project imports:
import 'package:network_scanner/models/animated_list_model.dart';
import 'package:network_scanner/ping/repository/repository.dart';
import 'package:network_scanner/shared/shared_widgets.dart';

class PingCard extends StatelessWidget {
  const PingCard({
    required this.list,
    required this.item,
    required this.addr,
    this.hasError = false,
    super.key,
  });

  final AnimatedListModel<PingData?> list;
  final PingData item;
  final String addr;
  final bool hasError;

  @override
  Widget build(BuildContext context) {
    final isIos = Theme.of(context).platform == TargetPlatform.iOS;

    return DataCard(
      padding: EdgeInsets.zero,
      margin: const EdgeInsets.symmetric(vertical: 5),
      child: ListTile(
        contentPadding: const EdgeInsets.only(left: 8, right: 16),
        leading: hasError
            ? StatusCard(
                color: isIos ? CupertinoColors.systemRed : Colors.red,
                text: 'Не в сети',
              )
            : StatusCard(
                color: isIos ? CupertinoColors.systemGreen : Colors.green,
                text: 'Онлайн',
              ),
        title: Text(
          addr,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: isIos ? CupertinoColors.label.resolveFrom(context) : null,
          ),
        ),
        subtitle: hasError
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Seq. pos.: ${list.indexOf(item) + 1}',
                    style: TextStyle(
                      color: isIos
                          ? CupertinoColors.label.resolveFrom(context)
                          : null,
                    ),
                  ),
                  Text(
                    'TTL: N/A',
                    style: TextStyle(
                      color: isIos
                          ? CupertinoColors.label.resolveFrom(context)
                          : null,
                    ),
                  ),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Seq. pos.: ${item.response!.seq} ',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: isIos
                              ? CupertinoColors.label.resolveFrom(context)
                              : null,
                        ),
                  ),
                  Text(
                    'TTL: ${item.response!.ttl}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: isIos
                              ? CupertinoColors.label.resolveFrom(context)
                              : null,
                        ),
                  ),
                ],
              ),
        trailing: hasError
            ? Text(
                context.read<PingRepository>().getErrorDesc(item.error!),
              )
            : Text(
                '${item.response!.time!.inMilliseconds} ms',
                style: TextStyle(
                  color: item.response!.time!.inMilliseconds < 75
                      ? isIos
                          ? CupertinoColors.systemGreen
                          : Colors.green
                      : item.response!.time!.inMilliseconds < 150
                          ? isIos
                              ? CupertinoColors.systemYellow
                              : Colors.yellow[700]
                          : isIos
                              ? CupertinoColors.systemRed
                              : Colors.red[700],
                ),
              ),
      ),
    );
  }
}
