enum WolStatus {
  success,
  fail,
}
