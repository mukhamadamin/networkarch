// Dart imports:
import 'dart:async';

// Flutter imports:
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

// Package imports:
import 'package:adapty_flutter/adapty_flutter.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive/hive.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:sentry_flutter/sentry_flutter.dart';

// Project imports:
import 'package:network_scanner/constants.dart';
import 'package:network_scanner/introduction/introduction.dart';
import 'package:network_scanner/overview/views/overview_view.dart';
import 'package:network_scanner/permissions/permissions.dart';
import 'package:network_scanner/settings/settings.dart';
import 'package:network_scanner/shared/shared_widgets.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _selectedIndex = 0;

  bool? _hasIntroductionBeenShown;
  StreamSubscription<BoxEvent>? _hasIntroductionBeenShownSubscription;

  @override
  void initState() {
    super.initState();

    final settingsBox = Hive.box<bool>('settings');

    _hasIntroductionBeenShown = settingsBox.get(
      'hasIntroductionBeenShown',
      defaultValue: false,
    );

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      if (!_hasIntroductionBeenShown!) {
        if (Theme.of(context).platform == TargetPlatform.iOS) {
          CupertinoScaffold.showCupertinoModalBottomSheet<void>(
            context: context,
            enableDrag: false,
            builder: (context) => const IosOnboarding(),
          );
        } else {
          showMaterialModalBottomSheet<void>(
            context: context,
            enableDrag: false,
            builder: Constants.routes['/introduction']!,
          );
        }
      }
    });

    _hasIntroductionBeenShownSubscription =
        settingsBox.watch(key: 'hasIntroductionBeenShown').listen((event) {
      if (event.value is bool) {
        setState(() {
          _hasIntroductionBeenShown = event.value as bool;
        });
      }
      if (!_hasIntroductionBeenShown!) {
        if (Theme.of(context).platform == TargetPlatform.iOS) {
          CupertinoScaffold.showCupertinoModalBottomSheet<void>(
            context: context,
            builder: (context) => const IosOnboarding(),
          );
        } else {
          showMaterialModalBottomSheet<void>(
            context: context,
            builder: Constants.routes['/introduction']!,
          );
        }
      }
    });

    if (kReleaseMode) {
      _fetchIapData();
    }

    context
        .read<PermissionsBloc>()
        .add(const PermissionsStatusRefreshRequested());
  }

  @override
  void dispose() {
    super.dispose();

    _hasIntroductionBeenShownSubscription?.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return PlatformWidget(
      androidBuilder: _androidBuilder,
      iosBuilder: _iosBuilder,
    );
  }

  Widget _androidBuilder(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            _selectedIndex == 0 ? const Text('Обзор') : const Text('Настройки'),
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: _pages,
      ),
      bottomNavigationBar: NavigationBar(
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Обзор',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings_rounded),
            label: 'Настройки',
          ),
        ],
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) =>
            setState(() => _selectedIndex = index),
      ),
    );
  }

  Widget _iosBuilder(BuildContext context) {
    return CupertinoTabScaffold(
      tabBar: CupertinoTabBar(
        items: const [
          BottomNavigationBarItem(
            label: 'Обзор',
            icon: Icon(CupertinoIcons.home),
          ),
          BottomNavigationBarItem(
            label: 'Настройки',
            icon: Icon(CupertinoIcons.settings),
          ),
        ],
      ),
      tabBuilder: (context, index) {
        switch (index) {
          case 0:
            return CupertinoTabView(
              defaultTitle: 'Обзор',
              routes: Constants.routes,
              builder: Constants.routes['/overview'],
            );
          case 1:
            return CupertinoTabView(
              defaultTitle: 'Настройки',
              routes: Constants.routes,
              builder: Constants.routes['/settings'],
            );
          default:
            throw Exception('Неожиданная вкладка');
        }
      },
    );
  }

  Future<void> _fetchIapData() async {
    try {
      final purchaserInfo = await Adapty().getProfile();
      if (purchaserInfo.accessLevels['premium']?.isActive ?? false) {
        await Hive.box<bool>('iap').put('isPremiumGranted', true);
      } else {
        await Hive.box<bool>('iap').put('isPremiumGranted', false);
      }
    } catch (e) {
      unawaited(Sentry.captureException(e));
    }
  }
}

const List<Widget> _pages = <Widget>[
  OverviewView(),
  SettingsView(),
];
